# MOOD Launcher (Galaxy M06)

A starter native Android launcher project. It is configured as a HOME app and includes:
- Multiple named profiles with one-tap switching inside MOOD
- Per-profile wallpaper selection (applies to Android home and lock screen)
- Per-profile app visibility/shortcut selection
- Android AppWidgetHost-based widget picking and profile-specific widget IDs
- Per-profile background colour

## Build an APK
1. Install Android Studio (recent version) on a computer.
2. Open this folder as a project.
3. Let Gradle sync. The project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Transfer the generated APK to your Galaxy M06 and install it. You may need to allow installation from that file app.
6. Press Home and choose **MOOD** as the default Home app. You can change it later in Settings > Apps > Choose default apps > Home app.

## First run
- Tap **＋ Profile** to create a mood.
- Tap **Wallpaper** to choose a photo for that profile.
- Tap **Apps** to choose which app shortcuts appear in that profile. An empty selection means show all apps.
- Tap **Add widget** to pick an Android widget. The app may show the system widget permission/configuration flow.
- Tap another profile chip to switch. MOOD will redraw its app layout and colour and apply that profile's saved wallpaper.

## Important Android limitations
- Android launchers can host widgets, but individual widget providers may require their own setup/permission steps.
- Wallpaper changes are applied through Android's WallpaperManager. Some OEM/Android versions may restrict lock-screen wallpaper updates; if so, set the lock wallpaper separately in Samsung Wallpaper and style.
- This starter launcher does not replace Samsung's notification shade, Settings, navigation bar, or system font. App icon artwork is currently supplied by each installed app; custom per-app icon artwork and drag-and-drop widget resizing are not implemented yet.
- Some app widgets are designed for specific launcher sizes and may need further layout tuning.
- This is source code, not a prebuilt APK. Build it in Android Studio to create the installable APK.
