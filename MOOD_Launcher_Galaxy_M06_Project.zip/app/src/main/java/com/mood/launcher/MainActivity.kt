package com.mood.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.appwidget.AppWidgetHost
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

data class MoodProfile(
    var id: String,
    var name: String,
    var color: Int,
    var wallpaper: String = "",
    var apps: MutableList<String> = mutableListOf(),
    var widgets: MutableList<Int> = mutableListOf()
)

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("mood_data", MODE_PRIVATE) }
    private val hostId = 48291
    private lateinit var widgetHost: AppWidgetHost
    private lateinit var widgetManager: AppWidgetManager
    private lateinit var root: LinearLayout
    private lateinit var widgetArea: LinearLayout
    private var profiles = mutableListOf<MoodProfile>()
    private var activeId = "default"
    private val pickWallpaper = 101
    private val pickWidget = 102
    private val colors = listOf("#F7DCEB", "#DCE9F5", "#DCEBDD", "#E8DDF7", "#25232B", "#F4E7CF")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        widgetHost = AppWidgetHost(this, hostId)
        widgetManager = AppWidgetManager.getInstance(this)
        widgetHost.startListening()
        loadProfiles()
        render()
    }

    override fun onDestroy() {
        try { widgetHost.stopListening() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun loadProfiles() {
        val raw = prefs.getString("profiles", null)
        profiles.clear()
        if (raw != null) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val apps = mutableListOf<String>()
                    val aa = o.optJSONArray("apps") ?: JSONArray()
                    for (j in 0 until aa.length()) apps.add(aa.getString(j))
                    val widgets = mutableListOf<Int>()
                    val wa = o.optJSONArray("widgets") ?: JSONArray()
                    for (j in 0 until wa.length()) widgets.add(wa.getInt(j))
                    profiles.add(MoodProfile(o.getString("id"), o.getString("name"),
                        o.optInt("color", Color.rgb(247,220,235)), o.optString("wallpaper",""), apps, widgets))
                }
            } catch (_: Exception) { profiles.clear() }
        }
        if (profiles.isEmpty()) profiles.add(MoodProfile("default", "My first mood", Color.rgb(247,220,235)))
        activeId = prefs.getString("active", profiles.first().id) ?: profiles.first().id
        if (profiles.none { it.id == activeId }) activeId = profiles.first().id
        save()
    }

    private fun save() {
        val arr = JSONArray()
        profiles.forEach { p ->
            val o = JSONObject()
            o.put("id", p.id); o.put("name", p.name); o.put("color", p.color)
            o.put("wallpaper", p.wallpaper)
            val apps = JSONArray(); p.apps.forEach { apps.put(it) }; o.put("apps", apps)
            val widgets = JSONArray(); p.widgets.forEach { widgets.put(it) }; o.put("widgets", widgets)
            arr.put(o)
        }
        prefs.edit().putString("profiles", arr.toString()).putString("active", activeId).apply()
    }

    private fun current() = profiles.first { it.id == activeId }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(value: String, size: Float, color: Int = Color.DKGRAY, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply { text = label; isAllCaps = false; setOnClickListener { action() } }

    private fun render() {
        val p = current()
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(12))
            setBackgroundColor(p.color)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(text("MOOD.", 30f, Color.rgb(45,35,48), true))
        content.addView(text("YOUR PHONE. YOUR AESTHETIC.", 11f, Color.DKGRAY, true))
        val heading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(16), 0, dp(8))
        }
        heading.addView(text(p.name, 23f, Color.rgb(45,35,48), true), LinearLayout.LayoutParams(0, -2, 1f))
        heading.addView(button("＋ Profile") { createProfile() })
        content.addView(heading)
        content.addView(text("Switch your mood", 13f, Color.DKGRAY, true))
        val profileRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        profiles.forEach { profile ->
            val b = Button(this).apply {
                text = if (profile.id == activeId) "✓ ${profile.name}" else profile.name
                isAllCaps = false
                setOnClickListener { switchTo(profile.id) }
            }
            profileRow.addView(b, LinearLayout.LayoutParams(-2, dp(48)).apply { marginEnd = dp(6) })
        }
        content.addView(profileRow)
        content.addView(text("Your space", 18f, Color.rgb(45,35,48), true).apply {
            setPadding(0, dp(18), 0, dp(6))
        })
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(button("Wallpaper") { chooseWallpaper() })
        actions.addView(button("Apps") { chooseApps() })
        actions.addView(button("Add widget") { addWidget() })
        content.addView(actions)
        content.addView(text("Widgets", 16f, Color.DKGRAY, true).apply { setPadding(0, dp(10), 0, dp(4)) })
        widgetArea = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(widgetArea)
        restoreWidgets(p)
        content.addView(text("Apps", 16f, Color.DKGRAY, true).apply { setPadding(0, dp(14), 0, dp(4)) })
        val apps = installedApps().filter { p.apps.isEmpty() || p.apps.contains(it.packageName) }
        val grid = GridLayout(this).apply { columnCount = 4 }
        apps.forEach { info ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                setPadding(dp(4), dp(8), dp(4), dp(8))
                setOnClickListener {
                    packageManager.getLaunchIntentForPackage(info.packageName)?.let { startActivity(it) }
                }
                addView(ImageView(this@MainActivity).apply {
                    setImageDrawable(info.loadIcon(packageManager))
                    layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
                })
                addView(text(info.loadLabel(packageManager).toString(), 10f, Color.DKGRAY).apply {
                    gravity = Gravity.CENTER; maxLines = 2
                })
            }
            grid.addView(item, ViewGroup.LayoutParams(0, dp(78)))
            val lp = item.layoutParams as GridLayout.LayoutParams
            lp.width = 0; lp.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            item.layoutParams = lp
        }
        content.addView(grid)
        content.addView(button("Edit profile name / colour") { editProfile() })
        content.addView(button("Delete this profile") { deleteProfile() })
        content.addView(text("Tip: set MOOD as your Home app to use it as your launcher.", 11f, Color.DKGRAY).apply {
            setPadding(0, dp(12), 0, dp(12))
        })
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun installedApps() = packageManager.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
    ).filter { it.activityInfo.packageName != packageName }.sortedBy { it.loadLabel(packageManager).toString().lowercase() }

    private fun switchTo(id: String) {
        activeId = id
        save()
        applyWallpaper(current())
        render()
        Toast.makeText(this, "Switched to ${current().name}", Toast.LENGTH_SHORT).show()
    }

    private fun applyWallpaper(p: MoodProfile) {
        if (p.wallpaper.isBlank()) return
        try {
            contentResolver.openInputStream(Uri.parse(p.wallpaper))?.use { stream ->
                val bitmap = BitmapFactory.decodeStream(stream)
                if (bitmap != null) WallpaperManager.getInstance(this).setBitmap(
                    bitmap, null, true,
                    WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                )
            }
        } catch (_: Exception) {
            Toast.makeText(this, "Couldn't apply this wallpaper. Please choose it again.", Toast.LENGTH_LONG).show()
        }
    }

    private fun chooseWallpaper() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickWallpaper)
    }

    private fun chooseApps() {
        val all = installedApps()
        val p = current()
        val labels = all.map { it.loadLabel(packageManager).toString() }.toTypedArray()
        val checked = BooleanArray(all.size) { p.apps.isEmpty() || p.apps.contains(all[it].activityInfo.packageName) }
        AlertDialog.Builder(this).setTitle("Apps in ${p.name}")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked -> checked[which] = isChecked }
            .setPositiveButton("Save") { _, _ ->
                p.apps = all.indices.filter { checked[it] }.map { all[it].activityInfo.packageName }.distinct().toMutableList()
                save(); render()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun createProfile() {
        val input = EditText(this).apply { hint = "e.g. Soft pink, Midnight, Study" }
        AlertDialog.Builder(this).setTitle("Create a mood").setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().trim().ifBlank { "New mood" }
                val color = colors[profiles.size % colors.size].let { Color.parseColor(it) }
                val p = MoodProfile(System.currentTimeMillis().toString(), name, color)
                profiles.add(p); save(); switchTo(p.id)
            }.setNegativeButton("Cancel", null).show()
    }

    private fun editProfile() {
        val p = current()
        val input = EditText(this).apply { setText(p.name); hint = "Profile name" }
        val options = colors.map { it }.toTypedArray()
        var chosen = p.color
        AlertDialog.Builder(this).setTitle("Edit ${p.name}").setView(input)
            .setNeutralButton("Next colour") { _, _ ->
                val index = colors.indexOfFirst { Color.parseColor(it) == p.color }
                p.color = Color.parseColor(colors[(index + 1).coerceAtLeast(0) % colors.size])
                p.name = input.text.toString().trim().ifBlank { p.name }; save(); render()
            }
            .setPositiveButton("Save name") { _, _ ->
                p.name = input.text.toString().trim().ifBlank { p.name }; save(); render()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun deleteProfile() {
        if (profiles.size == 1) {
            Toast.makeText(this, "Keep at least one profile.", Toast.LENGTH_SHORT).show(); return
        }
        AlertDialog.Builder(this).setTitle("Delete ${current().name}?")
            .setMessage("This removes the saved MOOD profile. Android widgets added to it may need to be removed separately.")
            .setNegativeButton("Cancel", null).setPositiveButton("Delete") { _, _ ->
                profiles.remove(current()); activeId = profiles.first().id; save(); render()
            }.show()
    }

    private fun addWidget() {
        val id = widgetHost.allocateAppWidgetId()
        val pick = Intent(AppWidgetManager.ACTION_APPWIDGET_PICK).putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        startActivityForResult(pick, pickWidget)
    }

    private fun restoreWidgets(p: MoodProfile) {
        p.widgets.forEach { id ->
            try {
                val info = widgetManager.getAppWidgetInfo(id) ?: return@forEach
                val view = widgetHost.createView(this, id, info)
                view.setAppWidget(id, info)
                widgetArea.addView(view, LinearLayout.LayoutParams(-1, dp(160)).apply {
                    bottomMargin = dp(8)
                })
            } catch (_: Exception) { }
        }
    }

    @Deprecated("Legacy activity result API retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        if (requestCode == pickWallpaper) {
            val uri = data.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            current().wallpaper = uri.toString(); save(); applyWallpaper(current()); render()
        } else if (requestCode == pickWidget) {
            val id = data.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
            if (id < 0) return
            val info = widgetManager.getAppWidgetInfo(id)
            if (info != null) {
                current().widgets.add(id); save()
                val view = widgetHost.createView(this, id, info)
                view.setAppWidget(id, info)
                widgetArea.addView(view, LinearLayout.LayoutParams(-1, dp(160)).apply { bottomMargin = dp(8) })
            } else widgetHost.deleteAppWidgetId(id)
        }
    }
}
